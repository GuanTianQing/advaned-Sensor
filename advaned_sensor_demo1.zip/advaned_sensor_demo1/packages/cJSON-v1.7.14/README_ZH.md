# cJSON

中文页 | [English](README.md)

超轻量级的 C 语言 json 解析库 

官方仓库：https://github.com/DaveGamble/cJSON

欢迎提交PR来同步官方仓库
